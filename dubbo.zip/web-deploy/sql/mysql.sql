/* grant all privileges on dubbo_registry.* to dubbo_registry@'%' identified by 'dubbo_registry'; */
/* create database dubbo_registry; */
/* use dubbo_registry; */

/* 注册中心信息表 */
create table registries (
  id                int auto_increment not null, /* 唯一标识 */
  registry_address  varchar(100),                /* 注册中心地址 */
  console_url       varchar(200),                /* 注册中心控制台URL */
  gmt_expired       datetime,                    /* 过期时间 */
  gmt_create        datetime,                    /* 创建时间 */
  gmt_modified      datetime,                    /* 最后修改时间 */
  primary key (id),
  index idx_registries_address(registry_address), /* 逻辑上唯一 */
  index idx_registries_expired(gmt_expired)
) ENGINE = InnoDB;

/* 服务提供者信息表 */
create table providers (
  id                 int auto_increment not null, /* 唯一标识 */
  service_name       varchar(200),                /* 提供者所提供的服务名称 */
  service_url        varchar(500),                /* 提供者提供服务的地址*/
  service_parameters varchar(2000),               /* 提供者提供服务的参数 */
  provider_address   varchar(100),                /* 提供者地址 */
  registry_address   varchar(100),                /* 提供者连接的注册中心地址 */
  application        varchar(100),                /* 提供者来源应用名 */
  username           varchar(100),                /* 注册者帐号 */
  statistics         varchar(1000),               /* 服务调用统计信息 */
  statistics_date    datetime,                    /* 服务调用统计时间 */
  dynamic            char(1),                     /* 是否为动态注册服务 */
  enabled            char(1),                     /* 是否启用 */
  gmt_create         datetime,                    /* 创建时间 */
  gmt_modified       datetime,                    /* 最后修改时间 */
  primary key (id),
  index idx_providers_service(service_name, service_url), /* 逻辑上唯一 */
  index idx_providers_provider(provider_address, service_name),
  index idx_providers_registry(registry_address),
  index idx_providers_application(application)
) ENGINE = InnoDB;

/* 服务消费者信息表 */
create table consumers (
  id                int auto_increment not null, /* 唯一标识 */
  service_name      varchar(200),                /* 消费者所引用的服务名称 */
  consumer_address  varchar(100),                /* 消费者地址 */
  registry_address  varchar(100),                /* 消费者连接的注册中心地址 */
  query_url         varchar(2000),               /* 消费者查询参数 */
  application       varchar(100),                /* 消费者来源应用名 */
  username          varchar(100),                /* 消费者帐号 */
  statistics        varchar(1000),               /* 服务调用统计信息 */
  statistics_date   datetime,                    /* 服务调用统计时间 */
  gmt_create        datetime,                    /* 创建时间 */
  gmt_modified      datetime,                    /* 最后修改时间 */
  primary key (id),
  index idx_consumers_service_consumer(service_name, consumer_address), /* 逻辑上唯一 */
  index idx_consumers_address(consumer_address),
  index idx_consumers_registry(registry_address),
  index idx_consumers_application(application)
) ENGINE = InnoDB;

/* 序号表 */
create table sequences (
  id              int auto_increment not null, /* 变更序号 */
  primary key (id)
) ENGINE = InnoDB;

/* 服务变更信息表 */
create table changes (
  id              int auto_increment not null, /* 唯一标识 */
  sequence        int,                         /* 变更序号 */
  type            char(1),                     /* 服务名称 */
  service_name    varchar(200),                /* 影响服务 */
  gmt_create      datetime,                    /* 创建时间 */
  gmt_modified    datetime,                    /* 最后修改时间 */
  primary key (id),
  index idx_changes_sequence(sequence),
  index idx_changes_type_service(type, service_name) /* 逻辑上唯一 */
) ENGINE = InnoDB;

/* 服务拥有者  */
create table owners (
  id                int auto_increment not null, /* 唯一标识 */
  service_name      varchar(200),                /* 服务名 */
  username          varchar(100),                /* 服务所属用户名 */
  gmt_create        datetime,                    /* 创建时间 */
  gmt_modified      datetime,                    /* 最后修改时间 */
  primary key (id),
  index idx_owners_service(service_name),
  index idx_owners_username(username)
) ENGINE = InnoDB;

/*路由信息表*/
create table routes (
  id           int auto_increment not null,     /* 唯一标识 */
  parent_id    int,                             /* 父规则ID */
  name         varchar(200) character set utf8, /* 路由规则名称 */
  service_name varchar(200),                    /* 服务名称 */
  match_rule   varchar(2000),                   /* 匹配规则 */
  filter_rule  varchar(2000),                   /* 过滤规则 */
  priority     int,                             /* 优先级，越大越优先 */
  enabled      char(1),                         /* 路由是否启用 */
  username     varchar(100),                    /* 规则创建者 */
  gmt_create   datetime,                        /* 创建时间 */
  gmt_modified datetime,                        /* 最后修改时间 */
  primary key (id),
  index idx_owners_service(service_name)
) ENGINE = InnoDB;

/* 服务提供者所属组信息表 */
create table clusters (
  id               int auto_increment not null, /* 唯一标识 */
  cluster_name     varchar(200),                /* 组名称 */
  address          varchar(100),                /* 客户端地址 */
  username         varchar(100),                /* 组创建者 */
  gmt_create       datetime,                    /* 创建时间 */
  gmt_modified     datetime,                    /* 最后修改时间 */
  primary key (id),
  index idx_clusters_name_address (cluster_name, address) /* 逻辑上唯一 */
) ENGINE = InnoDB;

/* 权重信息表 */
create table weights (
  id               int auto_increment not null, /* 唯一标识 */
  service_name     varchar(200),                /* 服务名称 */
  provider_address varchar(100),                /* 提供者地址 */
  weight           int,                         /* 权重值 */
  username         varchar(100),                /* 权重创建者 */
  gmt_create       datetime,                    /* 创建时间 */
  gmt_modified     datetime,                    /* 最后修改时间 */
  primary key (id),
  index idx_weights_service_provider (service_name, provider_address) /* 逻辑上唯一 */
) ENGINE = InnoDB;

/* 访问控制表 */
create table accesses (
  id               int auto_increment not null, /* 唯一标识 */
  service_name     varchar(200),                /* 服务名称 */
  consumer_address varchar(100),                /* 消费者地址 */
  allow            char(1),                     /* 是否允许访问 */
  username         varchar(100),                /* 权重创建者 */
  gmt_create       datetime,                    /* 创建时间 */
  gmt_modified     datetime,                    /* 最后修改时间 */
  primary key (id),
  index idx_accesses_service_consumer (service_name, consumer_address) /* 逻辑上唯一 */
) ENGINE = InnoDB;

/* 负载均衡 */
create table loadbalances (
  id               int auto_increment not null, /* 唯一标识 */
  service_name     varchar(200),                /* 服务名称 */
  method_name      varchar(200),                /* 方法名称 */
  strategy         varchar(100),                /* 策略名 */
  username         varchar(100),                /* 负载均衡创建者 */
  gmt_create       datetime,                    /* 创建时间 */
  gmt_modified     datetime,                    /* 最后修改时间 */
  primary key (id),
  index idx_loadbalances_service_method (service_name, method_name) /* 逻辑上唯一 */
) ENGINE = InnoDB;

/* 服务测试用例表 */
create table tests (
  id           int auto_increment not null,      /* 唯一标识 */
  name         varchar(200) character set utf8,  /* 测试用例名称 */
  service_name varchar(200),                     /* 服务名 */
  method       varchar(200),                     /* 方法签名 */
  parameters   varchar(2000) character set utf8, /* 参数值 */
  exception    char(1),                          /* 是否为异常 */
  result       varchar(2000) character set utf8, /* 结果 */
  username     varchar(100),                     /* 用户名 */
  auto_run     char(1),                          /* 自动运行 */
  gmt_create   datetime,                         /* 创建时间 */
  gmt_modified datetime,                         /* 最后修改时间 */
  primary key (id)
) ENGINE = InnoDB;

/* 操作记录表，记录所有的人为的操作 */
create table operations (
  id              int auto_increment not null,      /* 唯一标识 */
  username        varchar(100),                     /* 操作者 */
  operate_address varchar(200),                     /* 操作者地址 */
  operate_type    varchar(100),                     /* 操作类型 */
  data_type       varchar(100),                     /* 数据类型 */
  data            varchar(1000) character set utf8, /* 备注 */
  gmt_create      datetime,                         /* 创建时间 */
  gmt_modified    datetime,                         /* 最后修改时间 */
  primary key(id)
) ENGINE = InnoDB;

/* 配置表 */
create table configs (
  id           int auto_increment not null,     /* 唯一标识 */
  `key`        varchar(100),                    /* 配置键 */
  `value`      varchar(500) character set utf8, /* 配置值 */
  username     varchar(100),                    /* 用户名 */ 
  gmt_create   datetime,                        /* 创建时间 */
  gmt_modified datetime,                        /* 最后修改时间 */
  primary key(id),
  index idx_configs_key (`key`)
) ENGINE = InnoDB;

/* 功能表 */
create table features (
  id           int auto_increment not null, /* 唯一标识 */
  name         varchar(100),                /* 功能名 */
  enabled      char(1),                     /* 是否启用 */
  username     varchar(100),                /* 用户名 */ 
  gmt_create   datetime,                    /* 创建时间 */
  gmt_modified datetime,                    /* 最后修改时间 */
  primary key(id),
  index idx_features_name (name) /* 逻辑上唯一 */
) ENGINE = InnoDB;

/* 服务文档 */
create table documents (
  id           int auto_increment not null,        /* 唯一标识 */
  service_name varchar(200),                       /* 服务名 */
  title        varchar(100) character set utf8,   /* 文档标题 */
  type         char(1),                            /* 文档类型 */
  username     varchar(100),                       /* 文档作者 */
  content      varchar(2000) character set utf8,   /* 文档内容 */
  gmt_create   datetime,                           /* 创建时间 */
  gmt_modified datetime,                           /* 最后修改时间 */
  primary key (id),
  index idx_documents_service (service_name)
) ENGINE = InnoDB;

/* 服务质量等级协定(SLA) */
create table agreements (
  id                   int auto_increment not null, /* 唯一标识 */
  service_name         varchar(200),                /* 服务名 */
  consumer_application varchar(100),                /* 消费者应用 */
  level                char(1),                     /* 等级，高/中/低=H/M/L */
  articles             varchar(1000),               /* 协定条款 */
  username             varchar(100),                /* 用户名 */
  gmt_create           datetime,                    /* 创建时间 */
  gmt_modified         datetime,                    /* 最后修改时间 */
  primary key (id),
  index idx_agreements_service_consumer (service_name, consumer_application) /* 逻辑上唯一 */
) ENGINE = InnoDB;

/*用户信息表*/
create table users (
  id                int auto_increment not null,      /* 唯一标识 */
  username          varchar(100),                     /* 用户名 */
  password          char(32),                         /* 密码 */
  role              char(1),                          /* 角色 */
  creator           varchar(100),                     /* 用户创建者 */
  service_privilege varchar(1000),                    /* 服务权限，服务包名前缀，逗号分隔 */
  enabled           char(1),                          /* 用户是否启用 */
  name              varchar(50) character set utf8,   /* 用户显示名 */
  locale            varchar(10),                      /* 用户国际化语言及区域 */
  department        varchar(100) character set utf8,                     /* 用户部门 */
  email             varchar(300),                     /* 用户邮箱 */
  phone             varchar(100),                     /* 用户手机 */
  alitalk           varchar(100),                     /* 用户旺旺 */
  gmt_create        datetime,                         /* 创建时间 */
  gmt_modified      datetime,                         /* 最后修改时间 */
  primary key (id),
  index idx_users_username(username) /* 逻辑上唯一 */
) ENGINE = InnoDB;

insert into users(username, password, role, creator, enabled, service_privilege, name, locale, gmt_create, gmt_modified) values
	('root', md5('root:dubbo:hello1234'), 'R', 'root', '1', '*', 'root', 'zh', now(), now()),
	('admin', md5('admin:dubbo:hello1234'), 'A', 'root', '1', '*', 'admin', 'zh', now(), now()),
	('guest', md5('guest:dubbo:guest'), 'G', 'root', '1', '*', 'guest', 'zh', now(), now());

insert into configs(`key`, `value`, username, gmt_create, gmt_modified) values
	('MailEnabled','true','root',now(),now()),
	('MailHost','smtp.163.com','root',now(),now()),
	('MailPort','25','root',now(),now()),
	('MailFrom','dubbo_registry@163.com','root',now(),now()),
	('MailAuth','true','root',now(),now()),
	('MailUsername','dubbo_registry','root',now(),now()),
	('MailPassword','hell05a','root',now(),now()),
	('BulletinMessage','','root',now(),now()),
	('AllowAnonymousLogin','true','root',now(),now()),
	('AllowLegacyLogin','true','root',now(),now()),
	('LogLevel','WARN','root',now(),now()),
	('MaxThreadSize','200','root',now(),now()),
	('MaxConnectionSize','1000','root',now(),now()),
	('MaxCacheSize','1000','root',now(),now()),
	('MaxMailSize','1000','root',now(),now()),
	('HeartbeatCheckInterval','600000','root',now(),now()),
	('HeartbeatCheckTimeout','1800000','root',now(),now()),
	('AlivedCheckInterval','5000','root',now(),now()),
	('ChangedCheckInterval','5000','root',now(),now()),
	('FailedRetryInterval','5000','root',now(),now()),
	('DirtyCheckInterval','60000','root',now(),now()),
	('AutoRedirectInterval','3600000','root',now(),now()),
	('AutoRedirectThreshold','100','root',now(),now()),
	('AutoRedirectToleratePercent','20','root',now(),now()),
	('NotifyTimeout','5000','root',now(),now()),
	('RouteEnabled','true','root',now(),now());

insert into features(name, enabled, username, gmt_create, gmt_modified) values
	('Services', '1', 'root', now(), now()),
	('Applications', '1', 'root', now(), now()),
	('Providers', '1', 'root', now(), now()),
	('Consumers', '1', 'root', now(), now()),
	('Accesses', '1', 'root', now(), now()),
	('Registries', '1', 'root', now(), now()),
	('Connections', '1', 'root', now(), now()),
	('Routes', '1', 'root', now(), now()),
	('Clusters', '1', 'root', now(), now()),
	('Weights', '1', 'root', now(), now()),
	('Users', '1', 'root', now(), now()),
	('LoadBalances', '1', 'root', now(), now()),
	('StatusList', '1', 'root', now(), now()),
	('CachedList', '1', 'root', now(), now()),
	('FailedList', '1', 'root', now(), now()),
	('Tests', '1', 'root', now(), now()),
	('Documents', '1', 'root', now(), now()),
	('Agreements', '0', 'root', now(), now()),
	('Owned', '1', 'root', now(), now()),
	('Configs', '1', 'root', now(), now()),
	('Operations', '1', 'root', now(), now()),
	('Log', '1', 'root', now(), now()),
	('System', '1', 'root', now(), now()),
	('Help', '1', 'root', now(), now());
